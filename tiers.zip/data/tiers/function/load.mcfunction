scoreboard objectives add players playerKillCount "Kills"
scoreboard objectives add deaths deathCount "Deaths"
scoreboard objectives add pops minecraft.used:minecraft.totem_of_undying "Pops"
scoreboard objectives add points dummy "Points"
scoreboard objectives add tier dummy
scoreboard objectives add newtier dummy
scoreboard objectives add const dummy

scoreboard players set #10 const 10
scoreboard players set #15 const 15

team add lt5
team add ht5
team add lt4
team add ht4
team add lt3
team add ht3
team add lt2
team add ht2
team add lt1
team add ht1
team add ht1plus

team modify lt5 prefix [{"text":"LT5","color":"gray"},{"text":" | ","color":"gray"}]
team modify ht5 prefix [{"text":"HT5","color":"gray"},{"text":" | ","color":"gray"}]
team modify lt4 prefix [{"text":"LT4","color":"green"},{"text":" | ","color":"gray"}]
team modify ht4 prefix [{"text":"HT4","color":"green"},{"text":" | ","color":"gray"}]
team modify lt3 prefix [{"text":"LT3","color":"aqua"},{"text":" | ","color":"gray"}]
team modify ht3 prefix [{"text":"HT3","color":"aqua"},{"text":" | ","color":"gray"}]
team modify lt2 prefix [{"text":"LT2","color":"red"},{"text":" | ","color":"gray"}]
team modify ht2 prefix [{"text":"HT2","color":"dark_red"},{"text":" | ","color":"gray"}]
team modify lt1 prefix [{"text":"LT1","color":"yellow"},{"text":" | ","color":"gray"}]
team modify ht1 prefix [{"text":"HT1","color":"gold"},{"text":" | ","color":"gray"}]
team modify ht1plus prefix [{"text":"HT1","color":"gold"},{"text":"+","color":"dark_gray"},{"text":" | ","color":"gray"}]
team leave @s
scoreboard players set @s tier 0
title @s actionbar {"text":"you lost your rank","color":"red"}
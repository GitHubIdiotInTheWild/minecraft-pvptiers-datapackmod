scoreboard players add @s players 0
scoreboard players add @s deaths 0
scoreboard players add @s pops 0
scoreboard players add @s tier 0

scoreboard players operation @s points = @s players
scoreboard players operation @s points *= #10 const
scoreboard players operation #tmp const = @s deaths
scoreboard players operation #tmp const *= #15 const
scoreboard players operation @s points -= #tmp const
scoreboard players operation #tmp const = @s pops
scoreboard players operation #tmp const *= #15 const
scoreboard players operation @s points -= #tmp const
execute if score @s points matches ..-1 run scoreboard players set @s points 0

scoreboard players set @s newtier 0
execute if score @s points matches 600.. run scoreboard players set @s newtier 1
execute if score @s points matches 1150.. run scoreboard players set @s newtier 2
execute if score @s points matches 2150.. run scoreboard players set @s newtier 3
execute if score @s points matches 3200.. run scoreboard players set @s newtier 4
execute if score @s points matches 4200.. run scoreboard players set @s newtier 5
execute if score @s points matches 6100.. run scoreboard players set @s newtier 6
execute if score @s points matches 8200.. run scoreboard players set @s newtier 7
execute if score @s points matches 12000.. run scoreboard players set @s newtier 8
execute if score @s points matches 19000.. run scoreboard players set @s newtier 9
execute if score @s points matches 24000.. run scoreboard players set @s newtier 10
execute if score @s points matches 56000.. run scoreboard players set @s newtier 11

execute if score @s newtier = @s tier run return 0

scoreboard players set #up const 0
execute if score @s newtier > @s tier run scoreboard players set #up const 1

execute if score @s newtier matches 0 run return run function tiers:unrank
execute if score @s newtier matches 1 run function tiers:apply {tier:"lt5",label:"LT5"}
execute if score @s newtier matches 2 run function tiers:apply {tier:"ht5",label:"HT5"}
execute if score @s newtier matches 3 run function tiers:apply {tier:"lt4",label:"LT4"}
execute if score @s newtier matches 4 run function tiers:apply {tier:"ht4",label:"HT4"}
execute if score @s newtier matches 5 run function tiers:apply {tier:"lt3",label:"LT3"}
execute if score @s newtier matches 6 run function tiers:apply {tier:"ht3",label:"HT3"}
execute if score @s newtier matches 7 run function tiers:apply {tier:"lt2",label:"LT2"}
execute if score @s newtier matches 8 run function tiers:apply {tier:"ht2",label:"HT2"}
execute if score @s newtier matches 9 run function tiers:apply {tier:"lt1",label:"LT1"}
execute if score @s newtier matches 10 run function tiers:apply {tier:"ht1",label:"HT1"}
execute if score @s newtier matches 11 run function tiers:apply {tier:"ht1plus",label:"HT1+"}
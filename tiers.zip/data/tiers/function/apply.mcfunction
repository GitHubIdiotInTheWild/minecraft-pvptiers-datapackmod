$team join $(tier) @s
scoreboard players operation @s tier = @s newtier
execute if score #up const matches 1 run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1
execute if score #up const matches 1 run title @s subtitle {"text":"rank up!","color":"gray"}
$execute if score #up const matches 1 run title @s title {"text":"$(label)","bold":true,"color":"yellow"}
$execute if score #up const matches 1 run tellraw @a [{"selector":"@s"},{"text":" just ranked up to $(label)"}]
$execute if score #up const matches 0 run title @s actionbar {"text":"demoted to $(label)","color":"red"}